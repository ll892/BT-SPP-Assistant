package com.example.btsppassistant

import android.Manifest
import android.app.Activity
import android.bluetooth.BluetoothAdapter
import android.bluetooth.BluetoothDevice
import android.bluetooth.BluetoothSocket
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.*
import java.io.IOException
import java.io.InputStream
import java.io.OutputStream
import java.util.UUID
import kotlin.concurrent.thread

class MainActivity : Activity() {
    private val sppUuid: UUID = UUID.fromString("00001101-0000-1000-8000-00805F9B34FB")
    private val main = Handler(Looper.getMainLooper())
    private val adapter: BluetoothAdapter? by lazy { BluetoothAdapter.getDefaultAdapter() }
    private var socket: BluetoothSocket? = null
    private var input: InputStream? = null
    private var output: OutputStream? = null
    private var connected = false
    private var hexMode = false
    private var appendNewline = true
    private var autoTask: Runnable? = null
    private lateinit var status: TextView
    private lateinit var log: TextView
    private lateinit var inputText: EditText
    private lateinit var deviceSpinner: Spinner
    private lateinit var speed: SeekBar
    private lateinit var speedValue: TextView
    private val devices = mutableListOf<BluetoothDevice>()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        requestBtPermissions()
        buildUi()
        refreshDevices()
    }

    private fun requestBtPermissions() {
        if (Build.VERSION.SDK_INT >= 31) {
            val needed = arrayOf(Manifest.permission.BLUETOOTH_CONNECT, Manifest.permission.BLUETOOTH_SCAN)
                .filter { checkSelfPermission(it) != PackageManager.PERMISSION_GRANTED }
            if (needed.isNotEmpty()) requestPermissions(needed.toTypedArray(), 10)
        }
    }

    override fun onRequestPermissionsResult(requestCode: Int, permissions: Array<out String>, grantResults: IntArray) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (requestCode == 10) {
            if (grantResults.isNotEmpty() && grantResults.all { it == PackageManager.PERMISSION_GRANTED }) {
                refreshDevices()
            } else {
                toast("需要附近设备权限才能连接蓝牙设备")
            }
        }
    }

    private fun buildUi() {
        val root = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(16, 12, 16, 12); setBackgroundColor(0xFFF4F6FA.toInt()) }
        val title = TextView(this).apply { text = "BT SPP 助手"; textSize = 24f; setTextColor(0xFF14213D.toInt()); gravity = Gravity.CENTER; setPadding(0, 8, 0, 12) }
        root.addView(title)
        status = TextView(this).apply { text = "● 未连接"; textSize = 15f; setTextColor(0xFFB3261E.toInt()); gravity = Gravity.CENTER; setPadding(0, 4, 0, 10) }
        root.addView(status)
        val deviceRow = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
        deviceSpinner = Spinner(this)
        deviceRow.addView(deviceSpinner, LinearLayout.LayoutParams(0, 48, 1f))
        deviceRow.addView(button("刷新") { refreshDevices() })
        deviceRow.addView(button("连接") { connectSelected() })
        deviceRow.addView(button("断开") { disconnect() })
        root.addView(deviceRow)
        val tabs = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER }
        val serialPage = button("串口助手") { showSerial() }
        val carPage = button("平衡车控制") { showCar() }
        tabs.addView(serialPage, LinearLayout.LayoutParams(0, 48, 1f)); tabs.addView(carPage, LinearLayout.LayoutParams(0, 48, 1f))
        root.addView(tabs)
        val content = FrameLayoutCompat(this)
        root.addView(content, LinearLayout.LayoutParams(-1, 0, 1f))
        setContentView(root)
        pageContainer = content
        showSerial()
    }

    private lateinit var pageContainer: FrameLayoutCompat
    private fun showSerial() {
        pageContainer.removeAllViews()
        val box = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(0, 12, 0, 0) }
        val options = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
        val hex = CheckBox(this).apply { text = "HEX发送"; setOnCheckedChangeListener { _, v -> hexMode = v } }
        val nl = CheckBox(this).apply { text = "追加换行"; isChecked = true; setOnCheckedChangeListener { _, v -> appendNewline = v } }
        options.addView(hex); options.addView(nl); box.addView(options)
        log = TextView(this).apply { text = "接收/发送日志将在这里显示\n"; textSize = 13f; setTextColor(0xFF202124.toInt()); setPadding(10, 10, 10, 10) }
        val scroll = ScrollView(this).apply { addView(log) }
        box.addView(scroll, LinearLayout.LayoutParams(-1, 0, 1f))
        inputText = EditText(this).apply { hint = "输入要发送的数据"; singleLine = false; minLines = 1; maxLines = 3 }
        box.addView(inputText)
        val actions = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        actions.addView(button("发送") { sendInput() }, LinearLayout.LayoutParams(0, 48, 1f))
        actions.addView(button("清空") { log.text = "" }, LinearLayout.LayoutParams(0, 48, 1f))
        box.addView(actions)
        pageContainer.addView(box)
    }

    private fun showCar() {
        pageContainer.removeAllViews()
        val box = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; gravity = Gravity.CENTER_HORIZONTAL; setPadding(0, 12, 0, 0) }
        box.addView(TextView(this).apply { text = "平衡车控制台"; textSize = 20f; setTextColor(0xFF14213D.toInt()) })
        speedValue = TextView(this).apply { text = "速度参数：50"; textSize = 16f; setPadding(0, 8, 0, 0) }
        box.addView(speedValue)
        speed = SeekBar(this).apply { max = 100; progress = 50; setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(s: SeekBar?, p: Int, user: Boolean) { speedValue.text = "速度参数：$p" }
            override fun onStartTrackingTouch(s: SeekBar?) {}
            override fun onStopTrackingTouch(s: SeekBar?) { send("V${s?.progress ?: 50}") }
        }) }
        box.addView(speed, LinearLayout.LayoutParams(-1, 52))
        val grid = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; gravity = Gravity.CENTER }
        grid.addView(button("▲ 前进") { send("F") }, LinearLayout.LayoutParams(220, 64))
        val mid = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER }
        mid.addView(button("◀ 左转") { send("L") }, LinearLayout.LayoutParams(0, 64, 1f))
        mid.addView(button("■ 停止") { send("S") }, LinearLayout.LayoutParams(0, 64, 1f))
        mid.addView(button("右转 ▶") { send("R") }, LinearLayout.LayoutParams(0, 64, 1f))
        grid.addView(mid)
        grid.addView(button("▼ 后退") { send("B") }, LinearLayout.LayoutParams(220, 64))
        box.addView(grid)
        box.addView(button("紧急停止（发送 S）") { send("S") }.apply { setBackgroundColor(0xFFB3261E.toInt()); setTextColor(-1) }, LinearLayout.LayoutParams(-1, 56))
        box.addView(TextView(this).apply { text = "提示：默认指令 F/B/L/R/S，速度 V数值。需与你的 ESP32 固件协议一致。"; textSize = 12f; setTextColor(0xFF5F6368.toInt()); setPadding(4, 12, 4, 8) })
        val monitor = TextView(this).apply { text = "串口返回数据请在“串口助手”页面查看。"; textSize = 13f }
        box.addView(monitor)
        pageContainer.addView(ScrollView(this).apply { addView(box) })
    }

    private fun button(label: String, action: () -> Unit): Button = Button(this).apply { text = label; textSize = 13f; isAllCaps = false; setOnClickListener { action() } }

    private fun refreshDevices() {
        val a = adapter
        if (a == null) { toast("此手机不支持蓝牙"); return }
        if (Build.VERSION.SDK_INT >= 31 && checkSelfPermission(Manifest.permission.BLUETOOTH_CONNECT) != PackageManager.PERMISSION_GRANTED) { requestBtPermissions(); return }
        if (!a.isEnabled) { toast("请先打开手机蓝牙"); return }
        devices.clear()
        devices.addAll(a.bondedDevices.sortedBy { it.name ?: it.address })
        val names = if (devices.isEmpty()) listOf("没有已配对设备，请先在系统蓝牙设置中配对") else devices.map { "${it.name ?: "未知设备"} (${it.address})" }
        deviceSpinner.adapter = ArrayAdapter(this, android.R.layout.simple_spinner_dropdown_item, names)
        if (devices.isEmpty()) toast("未找到已配对设备")
    }

    private fun connectSelected() {
        if (devices.isEmpty()) { toast("请先刷新并配对蓝牙设备"); return }
        if (Build.VERSION.SDK_INT >= 31 && checkSelfPermission(Manifest.permission.BLUETOOTH_CONNECT) != PackageManager.PERMISSION_GRANTED) { requestBtPermissions(); return }
        val device = devices.getOrNull(deviceSpinner.selectedItemPosition) ?: return
        status.text = "● 正在连接 ${device.name ?: device.address}…"
        thread {
            try {
                adapter?.cancelDiscovery()
                val s = device.createRfcommSocketToServiceRecord(sppUuid)
                s.connect()
                socket = s; input = s.inputStream; output = s.outputStream; connected = true
                main.post { status.text = "● 已连接：${device.name ?: device.address}"; status.setTextColor(0xFF137333.toInt()); toast("SPP连接成功") }
                readLoop(s)
            } catch (e: Exception) {
                connected = false
                main.post { status.text = "● 连接失败"; status.setTextColor(0xFFB3261E.toInt()); toast("连接失败：${e.message ?: "请检查设备"}") }
                closeSocket()
            }
        }
    }

    private fun readLoop(s: BluetoothSocket) {
        val buffer = ByteArray(1024)
        try {
            while (connected && s.isConnected) {
                val count = s.inputStream.read(buffer)
                if (count > 0) {
                    val bytes = buffer.copyOf(count)
                    val value = bytes.toString(Charsets.UTF_8)
                    main.post { if (::log.isInitialized) log.append(value); }
                }
            }
        } catch (_: IOException) {
            main.post { status.text = "● 连接已断开"; status.setTextColor(0xFFB3261E.toInt()) }
        } finally { connected = false; closeSocket() }
    }

    private fun sendInput() {
        val raw = inputText.text.toString()
        if (raw.isBlank()) return
        try {
            val bytes = if (hexMode) parseHex(raw) else (raw + if (appendNewline) "\r\n" else "").toByteArray(Charsets.UTF_8)
            writeBytes(bytes)
            if (::log.isInitialized) log.append("\n[TX] $raw\n")
        } catch (e: Exception) { toast("发送失败：${e.message}") }
    }

    private fun parseHex(text: String): ByteArray {
        val clean = text.replace("0x", "", true).replace(" ", "").replace("\n", "").replace(",", "")
        require(clean.length % 2 == 0) { "HEX字符数量必须为偶数" }
        return ByteArray(clean.length / 2) { i -> clean.substring(i * 2, i * 2 + 2).toInt(16).toByte() }
    }

    private fun send(command: String) {
        try { writeBytes((command + "\r\n").toByteArray(Charsets.UTF_8)); if (::log.isInitialized) log.append("\n[TX] $command\n") }
        catch (e: Exception) { toast("未连接或发送失败：${e.message}") }
    }

    private fun writeBytes(bytes: ByteArray) {
        val out = output
        if (!connected || out == null) throw IOException("蓝牙未连接")
        thread { try { out.write(bytes); out.flush() } catch (e: Exception) { main.post { toast("发送失败：${e.message}") } } }
    }

    private fun disconnect() {
        connected = false; closeSocket()
        status.text = "● 未连接"; status.setTextColor(0xFFB3261E.toInt()); toast("已断开")
    }

    private fun closeSocket() { try { input?.close() } catch (_: Exception) {}; try { output?.close() } catch (_: Exception) {}; try { socket?.close() } catch (_: Exception) {}; input = null; output = null; socket = null }
    private fun toast(message: String) = main.post { Toast.makeText(this, message, Toast.LENGTH_SHORT).show() }
    override fun onDestroy() { disconnect(); super.onDestroy() }
}

class FrameLayoutCompat(context: android.content.Context) : android.widget.FrameLayout(context)

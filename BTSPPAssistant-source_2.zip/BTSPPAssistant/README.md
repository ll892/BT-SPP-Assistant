# BT SPP 助手

Android 原生 Kotlin 项目：经典蓝牙 SPP/RFCOMM 串口助手 + 平衡车控制页。

## 当前功能
- 列出手机已配对的经典蓝牙设备
- 通过标准 SPP UUID `00001101-0000-1000-8000-00805F9B34FB` 连接/断开
- UTF-8 文本发送、HEX 发送、接收日志
- CRLF 换行选项
- 平衡车方向按钮、速度滑条、停止按钮

## 平衡车指令注意
当前控制页默认发送以下占位协议，**不保证与你的 ESP32 固件一致**：
- 前进：`F\r\n`
- 后退：`B\r\n`
- 左转：`L\r\n`
- 右转：`R\r\n`
- 停止：`S\r\n`
- 速度：`V50\r\n`（数值随滑条变化）

请在实际驱动电机前，先架空车轮验证协议和停止指令。你的 ESP32 固件若使用其他命令格式，需要按实际解析代码修改 `MainActivity.kt`。

## 云端编译 APK（无需本地 Android SDK）
仓库已经包含 `.github/workflows/android.yml`。上传本项目到 GitHub 仓库后：
1. 打开仓库的 **Actions** 页面。
2. 选择 **Build Android APK**。
3. 点击 **Run workflow**（也可以在推送 main/master 分支时自动构建）。
4. 构建完成后，进入本次运行页面底部的 **Artifacts**。
5. 下载 `BT-SPP-Assistant-debug-apk`，解压得到 `app-debug.apk`，复制到安卓手机安装。

## 构建配置
- JDK 17
- Gradle 8.9
- Android Gradle Plugin 8.7.3
- Kotlin 2.0.21
- compileSdk 35 / minSdk 23 / targetSdk 35

## 使用
1. 手机系统蓝牙设置中先与 ESP32 经典蓝牙设备配对。
2. 打开 App，允许“附近设备”权限。
3. 刷新设备列表，选中 ESP32，点击连接。
4. 串口助手页面可收发数据；平衡车页面发送控制指令。

此版本是未签名的 debug APK，适合个人测试；不是 Google Play 发布包。
